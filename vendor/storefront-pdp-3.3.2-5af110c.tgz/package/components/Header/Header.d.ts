/**
 * ADOBE CONFIDENTIAL
 * __________________
 * Copyright 2024 Adobe
 * All Rights Reserved.
 * __________________
 * NOTICE: All information contained herein is, and remains
 * the property of Adobe and its suppliers, if any. The intellectual
 * and technical concepts contained herein are proprietary to Adobe
 * and its suppliers and are protected by all applicable intellectual
 * property laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe.
 */
import { FunctionComponent, VNode } from 'preact';
import { HTMLAttributes } from 'preact/compat';
export interface HeaderProps extends Omit<HTMLAttributes<HTMLDivElement>, 'title'> {
    title: VNode;
    sku: VNode;
    hideSku?: boolean;
    /** When provided, displayed as variant name (e.g. when all options are selected on a configurable product) */
    variantName?: VNode;
    /** When provided, displayed as variant SKU (e.g. when all options are selected on a configurable product) */
    variantSku?: VNode;
}
export declare const Header: FunctionComponent<HeaderProps>;
